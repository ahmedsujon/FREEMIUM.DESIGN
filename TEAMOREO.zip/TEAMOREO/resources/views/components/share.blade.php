<li><a href="https://www.facebook.com/sharer/sharer.php?u={{$url}}" class="share-btn facebook"
        target="_blank">Facebook</a></li>
