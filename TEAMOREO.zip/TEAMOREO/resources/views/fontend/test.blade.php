@if($items->count() > 0)
@foreach($items as $item)
<div class="col-lg-3">
    <div class="featured-item">
        <div class="featured-img">
            <a href="single_page.html"><img src="assets/img/image-1.png" alt="Image" class="img-fluid"></a>
        </div>
        <a href="single_page.html">Event Landing Page</a>
    </div>
</div>
@endforeach
@else
<h4 class="section-title">Related Category Item Not Font</h4>
@endif
