<!-- submit area -->
<section class="submit-area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="submit-content text-center main-content">
                    <p>You can share your resources with us. It will help other designers to use your resources in
                        their next projects.</p>
                    <a href="{{route('resource_info')}}" class="btn theme-btn">Submit Your Resource</a>
                </div>
            </div>
        </div>

    </div>
</section>
<!-- end of submit area -->
