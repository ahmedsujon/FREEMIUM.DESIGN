@extends('layouts.fontend')
@section('content')
<!-- featured area -->
@include('fontend.feature')
<!-- end of featured area -->

@include('fontend.new_relese')

@include('fontend.subscribe')
@include('fontend.submit_resource')
@endsection
