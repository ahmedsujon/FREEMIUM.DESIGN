<?php $__env->startSection('content'); ?>
<div class="tile">
    <h4 class="tile-title p-3">Edit Manufacturer</h4>
    <form action="<?php echo e(url('admin/category/'.$category->id)); ?>" method="POST">
        <?php echo $__env->make('admin.category.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo method_field('PATCH'); ?>
        <div class="tile-footer">
            <button class="btn btn-primary mr-1" type="submit">
                <i class="fa fa-plus" aria-hidden="true"></i><?php echo e(__('Update Category')); ?>

            </button>
            <a class="btn btn-secondary" href="<?php echo e(route('admin.category.index')); ?>">
                <i class="fa fa-fw fa-lg fa-times-circle"></i>Cancel
            </a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH L:\xampp\htdocs\TEAMOREO\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>