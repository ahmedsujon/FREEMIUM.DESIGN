<?php $__env->startSection('content'); ?>
<div class="tile">
    <h4 class="tile-title p-3">Edit Tag</h4>
    <form action="<?php echo e(url('admin/tags/'.$tag->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo $__env->make('admin.tag.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo method_field('PATCH'); ?>
        <div class="tile-footer">
            <button class="btn btn-primary mr-1" type="submit">
                <i class="fa fa-plus" aria-hidden="true"></i><?php echo e(__('Update Tag')); ?>

            </button>
            <a class="btn btn-secondary" href="<?php echo e(route('admin.tags.index')); ?>">
                <i class="fa fa-fw fa-lg fa-times-circle"></i>Cancel
            </a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH L:\xampp\htdocs\TEAMOREO\resources\views/admin/tag/edit.blade.php ENDPATH**/ ?>