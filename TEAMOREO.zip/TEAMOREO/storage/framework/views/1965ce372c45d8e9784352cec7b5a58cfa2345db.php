<?php $__env->startSection('content'); ?>
<div class="tile">
    <div class="tile-title-w-btn">
        <h4 class="title">Tag List</h4>
        <p><a class="btn btn-primary icon-btn" href="<?php echo e(route('admin.tags.create')); ?>"><i class="fa fa-plus"></i>Add
                Tag
            </a></p>
    </div>
    <div class="tile-body">
        <table class="table table-hover table-bordered data-table">
            <thead>
                <tr>
                    <th class="d-none"><?php echo e(_('#')); ?></th>
                    <th><?php echo e(_('Tag Name')); ?></th>
                    <th><?php echo e(_('Status')); ?></th>
                    <th><?php echo e(_('Created At')); ?></th>
                    <th><?php echo e(_('Action')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="d-none"><?php echo e($index); ?></td>
                    <td><?php echo e($tag->name); ?></td>
                    <td>
                        <?php if($tag->status == 1): ?>
                        <?php echo e(_('Active')); ?>

                        <?php elseif($tag->status == 0): ?>
                        <?php echo e(_('Inactive')); ?>

                        <?php else: ?>
                        <?php echo e(_('Unknown')); ?>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e(date('d M, Y', strtotime($tag->created_at))); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.tags.edit', $tag->id)); ?>" class="btn btn-primary btn-sm mr-3">Edit</a>
                        <form action="<?php echo e(route('admin.tags.destroy', $tag->id)); ?>" method="POST"
                            style="display: inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm mr-3"
                                onclick="return(confirm('are you sure to delete?'))">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH L:\xampp\htdocs\TEAMOREO\resources\views/admin/tag/index.blade.php ENDPATH**/ ?>