<?php $__env->startSection('content'); ?>
<div class="tile">
    <h4 class="tile-title">Create Advertise</h4>
    <form action="<?php echo e(route('admin.advertise.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo $__env->make('admin.advertise.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="tile-footer">
            <button class="btn btn-primary mr-1" type="submit">
                <i class="fa fa-fw fa-lg fa-check-circle"></i>
                Create
            </button>
            <a class="btn btn-secondary" href="<?php echo e(route('admin.advertise.index')); ?>">
                <i class="fa fa-fw fa-lg fa-times-circle"></i>
                Cancel
            </a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH L:\xampp\htdocs\TEAMOREO\resources\views/admin/advertise/create.blade.php ENDPATH**/ ?>