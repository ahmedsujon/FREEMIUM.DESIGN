<?php $__env->startSection('content'); ?>
<div class="tile">
    <div class="tile-title-w-btn">
        <h4 class="title">Advertise List</h4>
        <p><a class="btn btn-primary icon-btn" href="<?php echo e(route('admin.advertise.create')); ?>"><i
                    class="fa fa-plus"></i>Add
                Advertise
            </a></p>
    </div>
    <div class="tile-body">
        <table class="table table-hover table-bordered data-table">
            <thead>
                <tr>
                    <th class="d-none"><?php echo e(_('#')); ?></th>
                    <th><?php echo e(_('Advertise Name')); ?></th>
                    <th><?php echo e(_('Image')); ?></th>
                    <th><?php echo e(_('Preview Resource')); ?></th>
                    <th><?php echo e(_('Created At')); ?></th>
                    <th><?php echo e(_('Action')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $advertises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $advertise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="d-none"><?php echo e($index); ?></td>
                    <td><?php echo e($advertise->name); ?></td>
                    <td><img style="height:37px; border-radius:20px;" src="/storage/image/<?php echo e($advertise->image); ?>"></td>
                    <td><?php echo e($advertise->preview_resource); ?></td>
                    <td><?php echo e(date('d M, Y', strtotime($advertise->created_at))); ?></td>
                    <td>
                        <form action="<?php echo e(route('admin.advertise.destroy', $advertise->id)); ?>" method="POST"
                            style="display: inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm mr-3"
                                onclick="return(confirm('are you sure to delete?'))">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH L:\xampp\htdocs\TEAMOREO\resources\views/admin/advertise/index.blade.php ENDPATH**/ ?>