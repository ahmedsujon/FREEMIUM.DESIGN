<?php echo e($slot); ?>

<?php /**PATH L:\xampp\htdocs\TEAMOREO\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>