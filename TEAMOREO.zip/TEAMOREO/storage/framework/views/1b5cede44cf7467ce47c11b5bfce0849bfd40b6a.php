<?php echo csrf_field(); ?>
<div class="tile-body">
    <div class="form-group row">
        <div class="col-md-12 col-sm-12">
            <label class="control-label"><?php echo e(__('Item Name')); ?></label>
            <input type="text" name="title" id="title" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                placeholder="<?php echo e(__('Enter Item title')); ?>" value="<?php echo e(old('title') ?? $items->title); ?>" />
            <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
            <div class="form-control-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
    </div>
    <div class="form-group">
        <label class="control-label"><?php echo e(__('Description')); ?></label>
        <textarea name="description"
            class="form-control <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"><?php echo e(old('description') ?? $items->description); ?></textarea>
        <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
        <div class="form-control-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    </div>
    <div class="form-group row">
        <div class="col-md-12 col-sm-12">
            <label class="control-label"><?php echo e(__('Preview Resource')); ?></label>
            <input type="text" name="preview_resource" id="preview_resource"
                class="form-control <?php if ($errors->has('preview_resource')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('preview_resource'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                placeholder="<?php echo e(__('Enter Preview Resource')); ?>"
                value="<?php echo e(old('preview_resource') ?? $items->preview_resource); ?>" />
            <?php if ($errors->has('preview_resource')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('preview_resource'); ?>
            <div class="form-control-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
    </div>
    <div class="form-group row">
        <div class="col-md-12 col-sm-12">
            <label class="control-label"><?php echo e(__('Download Resource')); ?></label>
            <input type="text" name="download_resource" id="download_resource"
                class="form-control <?php if ($errors->has('download_resource')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('download_resource'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                placeholder="<?php echo e(__('Enter Download Resource')); ?>"
                value="<?php echo e(old('download_resource') ?? $items->download_resource); ?>" />
            <?php if ($errors->has('download_resource')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('download_resource'); ?>
            <div class="form-control-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
    </div>
    <div class="form-group row">
        <div class="col-md-6 col-sm-12">
            <label for="tag_id">Select Tag</label>
            <select name="tag_id" id="tag_id" class="form-control">
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($tag->id); ?>" <?php echo e($tag->id == $items->tag_id ? 'selected' : ''); ?>>
                    <?php echo e($tag->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-6 col-sm-12">
            <label for="category_id">Select Category</label>
            <select name="category_id" id="category_id" class="form-control">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" <?php echo e($category->id == $items->category_id ? 'selected' : ''); ?>>
                    <?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="col-md-6 col-sm-12">
        <div class="form-group">
            <label class="control-label" for="image">Identity Proof</label>
            <input class="form-control" name="image" type="file" id="image">
        </div>
    </div>
</div>
<?php /**PATH L:\xampp\htdocs\TEAMOREO\resources\views/admin/item/form.blade.php ENDPATH**/ ?>