<!-- footer area -->
<footer>
    <div class="container">
        <div class="border-top footer-content">
            <div class="row">
                <div class="col-lg-6">
                    <div class="footer-menu text-center text-lg-left">
                        <ul>
                            <li><a href="index.html">Home</a></li>
                            <li><a href="about.html">About</a></li>
                            <li><a href="contact.html">Contact</a></li>
                            <li><a href="advertise.html">Advirtise</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="copyright text-center text-lg-right">
                        Copyright © Freemium. A project by <a href="#">@Teamoreo</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer area end -->
<div class="scroll-top"><i class="fas fa-chevron-up"></i></div>

<!-- All js -->
<script src="<?php echo e(asset('fontend/js/vendor/modernizr-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('fontend/js/vendor/jquery-1.10.2.min.js')); ?>"></script>
<script src="<?php echo e(asset('fontend/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('fontend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('fontend/js/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('fontend/js/main.js')); ?>"></script>
</body>

</html>
<?php /**PATH L:\xampp\htdocs\TEAMOREO\resources\views/fontend/footer.blade.php ENDPATH**/ ?>