<section class="new-releases-area section-padding"></section>
<div class="container">
    <h2 class="section-title">New Releases</h2>
    <div class="row new-releases">

        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-4 col-sm-6">
            <div class="featured-item">
                <div class="featured-img">
                    <a href="<?php echo e(route('item.details', $item->slug)); ?>"><img src="/storage/image/<?php echo e($item->image); ?>"
                            alt="Image" class="img-fluid"></a>
                </div>
                <a href="<?php echo e(route('item.details', $item->slug)); ?>"><?php echo e($item->title); ?></a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <div class="show-all-btn text-center">
        <a href="<?php echo e(route('all_items')); ?>" class="btn theme-btn">Show All Resources</a>
    </div>
</div>
</section>
<?php /**PATH L:\xampp\htdocs\TEAMOREO\resources\views/fontend/new_relese.blade.php ENDPATH**/ ?>