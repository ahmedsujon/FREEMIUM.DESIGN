<?php echo csrf_field(); ?>
<div class="tile-body">
    <div class="form-group row">
        <div class="col-md-6 col-sm-12">
            <label class="control-label"><?php echo e(__('Advertise Name')); ?></label>
            <input type="text" name="name" id="name" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                placeholder="<?php echo e(__('Enter Advertise Name')); ?>" value="<?php echo e(old('name') ?? $advertise->name); ?>" />
            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
            <div class="form-control-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="col-md-6 col-sm-12">
            <label class="control-label"><?php echo e(__('Preview resource')); ?></label>
            <input type="text" name="preview_resource" id="preview_resource"
                class="form-control <?php if ($errors->has('preview_resource')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('preview_resource'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                placeholder="<?php echo e(__('Enter Advertise Name')); ?>"
                value="<?php echo e(old('preview_resource') ?? $advertise->preview_resource); ?>" />
            <?php if ($errors->has('preview_resource')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('preview_resource'); ?>
            <div class="form-control-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
    </div>
    <div class="col-md-6 col-sm-12">
        <div class="form-group">
            <label class="control-label" for="image">Identity Proof</label>
            <input class="form-control" name="image" type="file" id="image">
        </div>
    </div>
</div>
<?php /**PATH L:\xampp\htdocs\TEAMOREO\resources\views/admin/advertise/form.blade.php ENDPATH**/ ?>