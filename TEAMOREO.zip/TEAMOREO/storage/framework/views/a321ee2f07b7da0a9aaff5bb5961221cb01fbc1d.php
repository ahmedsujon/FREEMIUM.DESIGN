<?php $__env->startSection('content'); ?>
<div class="tile">
    <div class="tile-title-w-btn">
        <h4 class="title">Category List</h4>
        <p><a class="btn btn-primary icon-btn" href="<?php echo e(route('admin.category.create')); ?>"><i class="fa fa-plus"></i>Add
                Category
            </a></p>
    </div>
    <div class="tile-body">
        <table class="table table-hover table-bordered data-table">
            <thead>
                <tr>
                    <th class="d-none"><?php echo e(_('#')); ?></th>
                    <th><?php echo e(_('Category Name')); ?></th>
                    <th><?php echo e(_('Status')); ?></th>
                    <th><?php echo e(_('Created At')); ?></th>
                    <th><?php echo e(_('Action')); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="d-none"><?php echo e($index); ?></td>
                    <td><?php echo e($category->name); ?></td>
                    <td>
                        <?php if($category->status == 1): ?>
                        <?php echo e(_('Active')); ?>

                        <?php elseif($category->status == 0): ?>
                        <?php echo e(_('Inactive')); ?>

                        <?php else: ?>
                        <?php echo e(_('Unknown')); ?>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e(date('d M, Y', strtotime($category->created_at))); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.category.edit', $category->id)); ?>"
                            class="btn btn-primary btn-sm mr-3">Edit</a>
                        <form action="<?php echo e(route('admin.category.destroy', $category->id)); ?>" method="POST"
                            style="display: inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm mr-3"
                                onclick="return(confirm('are you sure to delete?'))">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH L:\xampp\htdocs\TEAMOREO\resources\views/admin/category/index.blade.php ENDPATH**/ ?>