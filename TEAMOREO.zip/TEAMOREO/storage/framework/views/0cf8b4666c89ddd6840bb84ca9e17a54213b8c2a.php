<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4">
        <div class="widget-small primary"><i class="icon fa fa-users fa-3x"></i>
            <div class="info">
                <h4>Agents</h4>
                <p><b>55</b></p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="widget-small info"><i class="icon fa fa-thumbs-o-up fa-3x"></i>
            <div class="info">
                <h4>Clients</h4>
                <p><b>55</b></p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="widget-small danger"><i class="icon fa fa-star fa-3x"></i>
            <div class="info">
                <h4>Schedules</h4>
                <p><b>55</b></p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH L:\xampp\htdocs\Team-Oreo\resources\views/dashboard.blade.php ENDPATH**/ ?>