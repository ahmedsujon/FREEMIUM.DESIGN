<?php $__env->startSection('content'); ?>
<section class="login-content">
    <div class="logo">
        <h1><?php echo e(config('app.name', 'PKAds')); ?></h1>
    </div>
    <div class="login-box">
        <form action="<?php echo e(route('login')); ?>" method="POST" class="login-form">
            <?php echo csrf_field(); ?>
            <h3 class="login-head">
                <i class="fa fa-lg fa-fw fa-user"></i>SIGN IN
            </h3>
            <div class="form-group">
                <label class="control-label"><?php echo e(__('E-Mail')); ?></label>
                <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>"
                    class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Email" required
                    autocomplete="email" autofocus>
                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                <div class="form-control-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="form-group">
                <label class="control-label"><?php echo e(__('Password')); ?></label>
                <input type="password" name="password" id="password"
                    class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Password" required
                    autocomplete="current-password">
                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                <div class="form-control-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="form-group">
                <div class="utility">
                    <div class="animated-checkbox">
                        <label>
                            <input type="checkbox" name="remember" id="remember"
                                <?php echo e(old('remember') ? 'checked' : 'checked'); ?>>
                            <span class="label-text">Stay Signed in</span>
                        </label>
                    </div>
                    <p class="semibold-text mb-2"><a href="#" data-toggle="flip">Forgot Password ?</a></p>
                </div>
            </div>
            <div class="form-group btn-container">
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fa fa-sign-in fa-lg fa-fw"></i><?php echo e(__('Login')); ?>

                </button>
            </div>
        </form>
        <form action="<?php echo e(route('password.email')); ?>" method="POST" class="forget-form">
            <?php echo csrf_field(); ?>
            <h3 class="login-head"><i class="fa fa-lg fa-fw fa-lock"></i>Forgot Password ?</h3>
            <div class="form-group">
                <label class="control-label"><?php echo e(__('E-Mail')); ?></label>
                <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>"
                    class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" placeholder="Email" required
                    autocomplete="email" autofocus>

                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                <div class="form-control-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="form-group btn-container">
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="fa fa-unlock fa-lg fa-fw"></i><?php echo e(__('Send Password Reset Link')); ?>

                </button>
            </div>
            <div class="form-group mt-3">
                <p class="semibold-text mb-0">
                    <a href="#" data-toggle="flip">
                        <i class="fa fa-angle-left fa-fw"></i> Back to Login
                    </a>
                </p>
            </div>
        </form>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH L:\xampp\htdocs\TEAMOREO\resources\views/auth/login.blade.php ENDPATH**/ ?>