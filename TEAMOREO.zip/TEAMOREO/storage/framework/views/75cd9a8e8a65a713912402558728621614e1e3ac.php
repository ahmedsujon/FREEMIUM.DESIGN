<!-- featured area -->
<section class="featured-area section-padding">
    <div class="container">
        <h2 class="section-title">Featured Resources</h2>
        <div class="row featured">
            <?php $__currentLoopData = $randomitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $randomitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="featured-item">
                    <div class="featured-img">
                        <a href="<?php echo e(route('item.details', $randomitem->slug)); ?>"><img
                                src="/storage/image/<?php echo e($randomitem->image); ?>" alt="Image" class="img-fluid"></a>
                    </div>
                    <a href="<?php echo e(route('item.details', $randomitem->slug)); ?>"><?php echo e($randomitem->title); ?></a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- end of featured area -->
<div>
    <div class="container">
        <div class="border-top"></div>
    </div>
</div>
<?php /**PATH L:\xampp\htdocs\TEAMOREO\resources\views/fontend/feature.blade.php ENDPATH**/ ?>