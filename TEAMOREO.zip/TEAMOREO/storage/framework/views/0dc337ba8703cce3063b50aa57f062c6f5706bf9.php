<?php $__env->startSection('content'); ?>
<?php
$link = \Illuminate\Support\Facades\URL::current();
?>
<section class="section-padding">
    <div class="container">
        <div class="add-img">
            <a href="#"><img src="/storage/image/<?php echo e($advertise[0]['image']); ?>" alt="Advertise" class="img-fluid"></a>
        </div>
        <div class="row">
            <div class="col-lg-7">
                <div class="left-side">
                    <div class="single-page-img">
                        <a href="<?php echo e($items->preview_resource); ?>" target="_blank"><img
                                src="/storage/image/<?php echo e($items->image); ?>" alt="" class="img-fluid"></a>
                    </div>
                    <ul class="share d-flex justify-content-between">
                        <?php echo $__env->make('components.share', ['url' => $link ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </ul>
                    <div class="single-page-content">
                        <h2 class="section-title text-left"><?php echo e($items->title); ?></h2>
                        <p><?php echo e($items->description); ?></p>
                        <ul class="tags">
                            <?php $__currentLoopData = App\Tag::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button><a
                                    href="<?php echo e(route('tag.items',$tag->slug)); ?>"><button><?php echo e($tag->name); ?></button></a></button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <a href="<?php echo e($items->download_resource); ?>" target="_blank" class="btn theme-btn">Download</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 d-none d-lg-block">
                <div class="right-side">
                    <a href="#"><img src="/storage/image/<?php echo e($advertise[1]['image']); ?>" alt="" class="img-fluid"></a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="featured-area section-padding">
    <div class="container">
        <h2 class="section-title">Similar resources</h2>
        <div class="row featured">
            <?php $__currentLoopData = $randomitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $randomitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="featured-item">
                    <div class="featured-img">
                        <a href="<?php echo e(route('item.details', $randomitem->slug)); ?>"><img
                                src="/storage/image/<?php echo e($randomitem->image); ?>" alt="Image" class="img-fluid"></a>
                    </div>
                    <a href="<?php echo e(route('item.details', $randomitem->slug)); ?>"><?php echo e($randomitem->title); ?></a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH L:\xampp\htdocs\TEAMOREO\resources\views/fontend/single_item.blade.php ENDPATH**/ ?>