<li><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e($url); ?>" class="share-btn facebook"
        target="_blank">Facebook</a></li>
<?php /**PATH L:\xampp\htdocs\TEAMOREO\resources\views/components/share.blade.php ENDPATH**/ ?>