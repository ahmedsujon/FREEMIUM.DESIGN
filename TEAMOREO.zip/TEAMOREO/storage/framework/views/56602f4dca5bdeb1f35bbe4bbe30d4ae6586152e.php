<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">


<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


    <title><?php echo e(config('app.name', 'TEAMOREO')); ?></title>


    <meta http-equiv="X-UA-Compatible" content="IE=edge">


    <!-- Scripts -->
    <script src="<?php echo e(asset('js/jquery-3.2.1.min.js')); ?>"></script>


    <!-- Styles -->
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">


    <!-- Font-icon css -->
    <link rel="stylesheet" type="text/css"
        href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<body class="app sidebar-mini rtl">
    <script>
        // If you put this on end of the body it doesn't work properly
        if (localStorage.getItem('sidebarStyle')) {
            $('.app').addClass('sidenav-toggled');
        }

    </script>
    <!-- Navbar -->
    <header class="app-header">
        <a class="app-header__logo" href="<?php echo e(url('admin/dashboard')); ?>">
            <?php echo e(config('app.name', 'TEAMOREO')); ?>

        </a>
        <!-- Sidebar toggle button -->
        <a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
        <!-- Navbar Right Menu -->
        <ul class="app-nav">
            <!-- User Menu -->
            <li class="dropdown">
                <a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu">
                    <i class="fa fa-user fa-lg"></i>
                </a>
                <ul class="dropdown-menu settings-menu dropdown-menu-right">
                    <li>
                        <a class="dropdown-item" href="<?php echo e(url('logout')); ?>" onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();">
                            <i class="fa fa-sign-out fa-lg"></i>
                            <?php echo e(__('Logout')); ?>

                        </a>
                        <form id="logout-form" action="<?php echo e(url('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                </ul>
            </li>
        </ul>
    </header>
    <!-- Sidebar menu -->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
        <div class="app-sidebar__user">
            <img class="app-sidebar__user-avatar" src="<?php echo e(asset('images/profile.png')); ?>" alt>
            <div>
                <p class="app-sidebar__user-name"></p>
                <p class="app-sidebar__user-designation">System Admin</p>
            </div>
        </div>
        <ul class="app-menu">
            <li>
                <a class="app-menu__item" href="<?php echo e(Route('dashboard')); ?>">
                    <i class="app-menu__icon fa fa-dashboard"></i>
                    <span class="app-menu__label"><?php echo e(__('Dashboard')); ?></span>
                </a>
            </li>
            <li class="treeview">
                <a class="app-menu__item" href="#" data-toggle="treeview">
                    <i class="app-menu__icon fa fa-pie-chart"></i>
                    <span class="app-menu__label"><?php echo e(__('Employee')); ?></span>
                    <i class="treeview-indicator fa fa-angle-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a class="treeview-item" href="#">
                            <i class="icon fa fa-circle-o"></i>
                            <?php echo e(__('All Employee')); ?>

                        </a>
                    </li>
                    <li>
                        <a class="treeview-item" href="#" rel="noopener">
                            <i class="icon fa fa-circle-o"></i>
                            <?php echo e(__('Add Employee')); ?>

                        </a>
                    </li>
                </ul>
            </li>
            <li class="treeview">
                <a class="app-menu__item" href="#" data-toggle="treeview">
                    <i class="app-menu__icon fa fa-laptop"></i>
                    <span class="app-menu__label"><?php echo e(__('Division')); ?></span>
                    <i class="treeview-indicator fa fa-angle-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a class="treeview-item" href="#">
                            <i class="icon fa fa-circle-o"></i>
                            <?php echo e(__('All Division')); ?>

                        </a>
                    </li>
                    <li>
                        <a class="treeview-item" href="#" rel="noopener">
                            <i class="icon fa fa-circle-o"></i>
                            <?php echo e(__('Add Division')); ?>

                        </a>
                    </li>
                </ul>
            </li>
            <li class="treeview">
                <a class="app-menu__item" href="#">
                    <i class="app-menu__icon fa fa-th-list"></i>
                    <span class="app-menu__label"><?php echo e(__('Leave')); ?></span>
                </a>
            </li>
        </ul>
    </aside>
    <main class="app-content"><?php echo $__env->yieldContent('content'); ?></main>
    <!-- Essential javascripts for application to work -->
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>" defer></script>
    <!-- The javascript plugin to display page loading on top -->
    <script src="<?php echo e(asset('js/plugins/pace.min.js')); ?>"></script>
    <!-- Data table plugin -->
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/jquery.dataTables.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/bootstrap-notify.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/bootstrap-datepicker.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/select2.min.js')); ?>"></script>
    <script type="text/javascript">
        $('.data-table').DataTable();
        $('.select2').select2();
        $('.date-picker').datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true,
            todayHighlight: true
        });

        $('.app-menu a[href^="' + location.href + '"].app-menu__item').addClass('active');
        $('a[href^="' + location.href + '"]').closest('.treeview').addClass('is-expanded');

    </script>
    <?php if(Session::has('response')): ?>
    <script>
        var toastData = {
            html: '<?php echo e(Session::get("response.message")); ?>',
            classes: '<?php echo e(Session::get("response.type") == "success" ? "green" : "red"); ?>'
        };
        $.notify({
            title: '',
            message: '<?php echo e(Session::get("response.message")); ?>',
            icon: '<?php echo e(Session::get("response.type") == "success" ? "fa fa-check" : "fa fa-close"); ?>'
        }, {
            type: '<?php echo e(Session::get("response.type") == "success" ? "success" : "danger"); ?>'
        });

    </script>
    <?php endif; ?>
</body>


</html>
<?php /**PATH L:\xampp\htdocs\Team-Oreo\resources\views/layouts/app.blade.php ENDPATH**/ ?>