<?php echo csrf_field(); ?>
<div class="tile-body">
    <div class="form-group row">
        <div class="col-md-6 col-sm-12">
            <label class="control-label"><?php echo e(__('Manufacturer Name')); ?></label>
            <input type="text" name="name" id="name" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                placeholder="<?php echo e(__('Enter Category Name')); ?>" value="<?php echo e(old('name') ?? $category->name); ?>" />
            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
            <div class="form-control-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="col-md-6 col-sm-12">
            <label class="control-label"><?php echo e(__('status')); ?></label>
            <select name="status" id="status" class="form-control <?php if ($errors->has('status')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('status'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                <option value=""><?php echo e(__('Select Status')); ?></option>
                <option value="1" <?php echo e($category->status === 1 ? 'selected':''); ?>><?php echo e(__('Active')); ?></option>
                <option value="0"><?php echo e(__('In-Active')); ?></option>
            </select>
            <?php if ($errors->has('status')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('status'); ?>
            <div class="form-control-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
    </div>
</div>
<?php /**PATH L:\xampp\htdocs\TEAMOREO\resources\views/admin/category/form.blade.php ENDPATH**/ ?>