<?php echo e($slot); ?>

<?php /**PATH L:\xampp\htdocs\Team-Oreo\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>