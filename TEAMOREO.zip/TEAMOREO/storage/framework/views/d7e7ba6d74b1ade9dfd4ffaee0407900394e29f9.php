<!doctype html>
<html class="no-js" lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Freemium | Resource Showcase</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('fontend/img/favicon.ico')); ?>" type="image/x-icon" />
    <!-- All CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('fontend/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fontend/css/fontawesome.all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fontend/css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fontend/css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fontend/css/responsive.css')); ?>">
</head>

<body>
    <!-- preloader start -->
    <div class="preloader">
        <div class="preloader-spinner"></div>
    </div>
    <!-- preloader end -->
    <!-- header -->
    <header class="header-area">
        <div class="container">
            <div class="header-top d-flex justify-content-between align-items-center">
                <div class="logo">
                    <a href="#">Freemium</a>
                </div>
                <div class="search-btn">
                    <form action="#">
                        <input type="text" placeholder="Search resources…">
                        <button><img src="<?php echo e(asset('fontend/img/icon.svg')); ?>" alt="icon"></button>
                    </form>
                </div>
            </div>
            <div class="header-bottom text-center">
                <nav class="main-menu">
                    <ul>
                        <li><a href="all_resources.html">All</a></li>
                        <li><a href="#">Web</a></li>
                        <li><a href="#">Wireframe</a></li>
                        <li><a href="#">Icon</a></li>
                        <li><a href="#">iOS</a></li>
                        <li><a href="#">Android</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <!-- end of header -->
<?php /**PATH L:\xampp\htdocs\TEAMOREO\resources\views/fontend/header.blade.php ENDPATH**/ ?>